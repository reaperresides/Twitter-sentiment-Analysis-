from django.shortcuts import render,HttpResponse,redirect
from sklearn.pipeline import Pipeline
import pickle
from sklearn.feature_extraction.text import CountVectorizer
import re
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords

filename = r"C:\virtual enviroments\sentiment model\new_project\model\modelBOW.pkl"
model = pickle.load(open(filename,"rb"))
Ps = PorterStemmer()

# Create your views here.
def index(request):
    return render(request,"index.html")



def result(request):
    if request.method=="POST":
        data = request.POST.get("sent")
        data = re.sub("[^A-Za-z]"," ",data).lower().split(" ")
        data = [Ps.stem(x) for x in data if x not in stopwords.words("english")]
        data = [" ".join(data)]
        data_ = model.predict(data)
        context = {"data":data_}
        return render(request,"result.html",context=context)
    return render(request,"result.html")